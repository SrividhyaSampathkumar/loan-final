from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] ='postgresql://postgres:root@localhost/online_loan_application_and_verification_system'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)

@app.route('/home')
def home():
   return render_template("HOME.html")   
@app.route('/login')
def login():
   return render_template("LOGIN.html")   
@app.route('/adminlogin')
def adminlogin():
   return render_template("ADMINLOGIN.html")   
@app.route('/about')
def about():
   return render_template("ABOUT.html")   
@app.route('/contact')
def contact():
   return render_template("CONTACT.html")
@app.route('/signup')
def signup():
   return render_template("SIGNUP.html")
@app.route('/upload')
def upload():
   return render_template("UPLOAD.html")
@app.route('/main')
def main():
   return render_template("MAIN.html")
@app.route('/application1')
def application1():
   return render_template("APPLICATION1.html")   
@app.route('/bank')
def bank():
   return render_template("BANK.html") 
@app.route('/userdetails')
def userdetails():
   return render_template("USERDETAILS.html",signup=signup.query.all()) 
@app.route('/userlogin/<name>')
def userlogin(name):
   return render_template("USERLOGIN.html",signup=signup.query.filter_by(Username='%s'%name))   
@app.route('/search')
def search():
   return render_template("SEARCH.html",application1=application1.query.all()) 
@app.route('/viewsearch/<name>')
def viewsearch(name):
   return render_template("VIEWSEARCH.html",application1=application1.query.filter_by(Loan='%s'%name)) 
@app.route('/loan')
def loan():
   return render_template("LOAN.html")
@app.route('/gender')
def gender():
   return render_template("GENDER.html")  
@app.route('/user')
def user():
   return render_template("USER.html",application1=application1.query.all())         
   
class signup(db.Model):
	id = db.Column('signu_id', db.Integer, primary_key = True)
	Username = db.Column(db.String(100))
	Password= db.Column(db.String(200))
	Re_enter_password = db.Column(db.String(200))
	Email = db.Column(db.String(100))
	def __init__(self, Username, Password, Re_enter_password, Email):
		self.Username = Username
		self.Password = Password
		self.Re_enter_password = Re_enter_password
		self.Email = Email
	@app.route('/signup', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
			if not request.form['Username'] or not request.form['Password'] or not request.form['Re_enter_password'] or not request.form['Email']:
				flash('Please enter all the fields', 'error')
			else:
				signu = signup(request.form['Username'], request.form['Password'], request.form['Re_enter_password'], request.form['Email'])
				db.session.add(signu)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('login'))
		return render_template('signup.html')	

@app.route('/login', methods=['POST','GET'])
def loginn():
	if request.method=='GET':
		return render_template('login.html')
	Username = request.form['Username']
	Password = request.form['Password']
	session['Username']=Username
	signu=signup.query.filter_by(Username=Username,Password=Password).first()
	if request.form['Password'] == 'admin' and request.form['Username'] == 'admin':
		return render_template("adminlogin.html")
	if signu is None:
		return render_template("login.html")
	else:
		return redirect(url_for("userlogin",name=Username))				

class application1(db.Model):
	id = db.Column('appli_id', db.Integer, primary_key = True)
	Username = db.Column(db.String(100))
	Firstname = db.Column(db.String(100))
	Lastname = db.Column(db.String(200))
	Email = db.Column(db.String(200))
	Place = db.Column(db.String(100))
	Country = db.Column(db.String(100))
	Gender = db.Column(db.String(100))
	Details = db.Column(db.String(200))
	Phone = db.Column(db.String(200))
	Amount_required = db.Column(db.String(100))
	Birthdate = db.Column(db.String(100))
	Salary = db.Column(db.String(200))
	Company_name = db.Column(db.String(200))
	Subject = db.Column(db.String(100))
	Loan = db.Column(db.String(200))
	Bank = db.Column(db.String(100))
	def __init__(self, Username, Firstname, Lastname, Email, Place, Country, Gender, Details, Phone, Amount_required, Birthdate, Salary, Company_name, Subject, Loan, Bank ):
		self.Username = Username
		self.Firstname = Firstname
		self.Lastname = Lastname
		self.Email = Email
		self.Place = Place
		self.Country = Country
		self.Gender = Gender
		self.Details = Details
		self.Phone = Phone
		self.Amount_required = Amount_required
		self.Birthdate = Birthdate
		self.Salary = Salary
		self.Company_name = Company_name
		self.Subject = Subject
		self.Loan = Loan
		self.Bank = Bank
	@app.route('/application1', methods = ['GET', 'POST'])
	def form():
		if request.method == 'POST':
			if not request.form['Username'] or not request.form['Firstname'] or not request.form['Lastname'] or not request.form['Email'] or not request.form['Place'] or not request.form['Country'] or not request.form['Gender']  or not request.form['Details'] or not request.form['Phone'] or not request.form['Amount_required'] or not request.form['Birthdate'] or not request.form['Salary'] or not request.form['Company_name'] or not request.form['Subject'] or not request.form['Loan'] or not request.form['Bank']:
				flash('Please enter all the fields', 'error')
			else:
				appli = application1(request.form['Username'], request.form['Firstname'], request.form['Lastname'], request.form['Email'], request.form['Place'], request.form['Country'], request.form['Gender'], request.form['Details'], request.form['Phone'], request.form['Amount_required'], request.form['Birthdate'], request.form['Salary'], request.form['Company_name'], request.form['Subject'], request.form['Loan'], request.form['Bank'])
				db.session.add(appli)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('upload'))
			return render_template('APPLICATION1.html')
			
			
class contact(db.Model):
	id = db.Column('contact_id', db.Integer, primary_key = True)
	USERNAME = db.Column(db.String(100))
	EMAIL = db.Column(db.String(200))
	PHONE = db.Column(db.String(200))
	FEEDBACK = db.Column(db.String(200))
	def __init__(self, USERNAME, EMAIL, PHONE, FEEDBACK): 
		self.USERNAME = USERNAME 
		self.EMAIL = EMAIL
		self.PHONE = PHONE
		self.FEEDBACK = FEEDBACK
	@app.route('/contact', methods = ['GET', 'POST'])
	def contact1():
		if request.method == 'POST':
			if not request.form['USERNAME'] or not request.form['EMAIL'] or not request.form['PHONE'] or not request.form['FEEDBACK']:
				flash('Please enter all the fields', 'error')
			else:
				contacts = contact(request.form['USERNAME'], request.form['EMAIL'], request.form['PHONE'], request.form['FEEDBACK'])
				db.session.add(contacts)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('home'))
			return render_template('CONTACT.html')



@app.route('/search_name', methods=['POST','GET'])
def search_name():
	if request.method=='POST':
		Username = request.form['Username']
		return redirect(url_for("viewsearch",name=Username))
		
class user(db.Model):
	id = db.Column('user_id', db.Integer, primary_key = True)
	Loan = db.Column(db.String(1000))
	Bank = db.Column(db.String(1000))
	def __init__(self, Loan, Bank): 
		self.Loan = Loan 
		self.Bank = Bank
	@app.route('/user1', methods = ['GET', 'POST'])
	def user1():
		if request.method == 'POST':
			if not request.form['Loan'] or not request.form['Bank']:
				flash('Please enter all the fields', 'error')
			else:
				users =user(request.form['Loan'], request.form['Bank'])
				db.session.add(users)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('keywords'))
		return render_template('keywords.html')	
class password(db.Model):
	id = db.Column('password_id', db.Integer, primary_key = True)
	USERNAME = db.Column(db.String(100))
	OLDPASSWORD = db.Column(db.String(200))
	NEWPASSWORD = db.Column(db.String(200))
	CPASSWORD = db.Column(db.String(200))
	def __init__(self, USERNAME, OLDPASSWORD, NEWPASSWORD, CPASSWORD ): 
		self.USERNAME = USERNAME 
		self.OLDPASSWORD = OLDPASSWORD
		self.NEWPASSWORD = NEWPASSWORD
		self.CPASSWORD = CPASSWORD
	@app.route('/password', methods = ['GET', 'POST'])
	def password1():
		if request.method == 'POST':
			if not request.form['USERNAME'] or not request.form['OLDPASSWORD'] or not request.form['NEWPASSWORD'] or not request.form['CPASSWORD']:
				flash('Please enter all the fields', 'error')
			else:
				passwords = password(request.form['USERNAME'], request.form['OLDPASSWORD'], request.form['NEWPASSWORD'], request.form['CPASSWORD'])
				db.session.add(passwords)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('adminlogin'))
		return render_template('password.html')	
		
		
class bank(db.Model):
	id = db.Column('bank_id', db.Integer, primary_key = True)
	BANK = db.Column(db.String(200))
	def __init__(self, BANK): 
		self.BANK = BANK
	@app.route('/bank1', methods = ['GET', 'POST'])
	def bank1():
		if request.method == 'POST':
			if not request.form['BANK']:
				flash('Please enter all the fields', 'error')
			else:
				banks = bank(request.form['BANK'])
				db.session.add(banks)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('loan'))
			return render_template('bank.html')
		
class loan(db.Model):
	id = db.Column('loan_id', db.Integer, primary_key = True)
	LOAN = db.Column(db.String(200))
	def __init__(self, LOAN): 
		self.LOAN = LOAN
	@app.route('/loan1', methods = ['GET', 'POST'])
	def loan1():
		if request.method == 'POST':
			if not request.form['LOAN']:
				flash('Please enter all the fields', 'error')
			else:
				loans = loan(request.form['LOAN'])
				db.session.add(loans)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('application1'))
			return render_template('loan.html')			
				
if __name__ == '__main__':
   db.create_all()
   app.run(debug = True)
